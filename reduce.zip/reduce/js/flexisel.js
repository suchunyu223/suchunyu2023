eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('(6($){$.1N.e=6(y){3 1g=$.1f({z:4,O:1P,1c:r,1e:1J,18:f,1D:r,1G:f,n:f,1I:{1L:{v:21,z:1},20:{v:1S,z:2},1U:{v:1T,z:14}}},y);3 5=$(M);3 8=$.1f(1g,y);3 9;3 g=f;3 o=8.z;3 R=5.x().1E;3 t=[];3 d={1a:6(){L M.1K(6(){d.1B();d.1k();d.1H()})},1H:6(){3 j=5.w();3 T=j.D();3 c=5.x();d.1w(8.1I);3 k=j.m();9=(k)/o;c.m(9);7(8.n){c.H().Q(c.I());c.H().Q(c.I());5.p({\'l\':-9})}5.1M();$(1j).1O("1n")},1B:6(){5.1C("h-e-1Y");5.1X("<q s=\'h-e-1W\'><q s=\'h-e-1Q\'></q><q s=\'1R\'></q></q>");5.X("1V").1C("h-e-A");3 C=5.w();7(8.1D){3 1d=$(".h-e-A N").m();3 1q=$(".h-e-A N").D();$(".h-e-A N").p("1h-m",1d);$(".h-e-A N").p("1h-D",1q)}$("<q s=\'h-e-J-l\'><i s=\'F F-1Z\'></i></q><q s=\'h-e-J-1i\'><i s=\'F F-22\'></i></q>").1u(C);7(8.n){3 1m=5.x().n();5.2q(1m)}},1k:6(){3 j=5.w();3 C=j.w();3 c=5.x();3 B=C.X(".h-e-J-l");3 E=C.X(".h-e-J-1i");$(1j).P("1n",6(Y){d.1t();3 k=$(j).m();3 T=$(j).D();9=(k)/o;c.m(9);7(8.n){5.p({\'l\':-9})}u{5.p({\'l\':0})}7(!8.n&&R<=o){B.1r(E).p(\'1s\',\'2r\')}u{B.1r(E).p(\'1s\',\'2j\');3 1o=(B.D())/2;3 U=(T/2)-1o;B.p("1p",U+"17");E.p("1p",U+"17")}});$(B).P("1b",6(Y){d.1A()});$(E).P("1b",6(Y){d.S()});7(8.18==f){$(".h-e-A").P({2l:6(){g=r},2m:6(){g=f}})}7(8.1c==f){2n(6(){7(g==f)d.S()},8.1e)}},1t:6(){3 V=$(\'2i\').m();7(8.1G){3 1F=t[t.1E-1].v;1x(3 i 16 t){7(V>=1F){o=8.z;1l}u{7(V<t[i].v){o=t[i].z;1l}u 2o}}}},1w:6(W){3 K=[];1x(3 i 16 W){K.2s(W[i])}K.2p(6(a,b){L a.v-b.v});t=K},1A:6(){7(5.1y().l<0){7(g==f){g=r;3 j=5.w();3 k=j.m();9=(k)/o;3 c=5.x();5.10({\'l\':"+="+9},{12:r,11:8.O,15:"13",Z:6(){7(8.n){c.H().Q(c.I())}d.G();g=f}})}}},S:6(){3 j=5.w();3 k=j.m();9=(k)/o;3 1z=(9-k);3 1v=(5.1y().l+((R-o)*9)-k);7((1z<=27.28(1v))&&(!8.n)){7(g==f){g=r;5.10({\'l\':"-="+9},{12:r,11:8.O,15:"13",Z:6(){d.G();g=f}})}}u 7(8.n){7(g==f){g=r;3 c=5.x();5.10({\'l\':"-="+9},{12:r,11:8.O,15:"13",Z:6(){c.I().1u(c.H());d.G();g=f}})}}},G:6(){3 j=5.w();3 c=5.x();3 k=j.m();9=(k)/o;c.m(9);7(8.n){5.p({\'l\':-9})}}};7(d[y]){L d[y].19(M,29.26.23.24(25,1))}u 7(2a y===\'5\'||!y){L d.1a.19(M)}u{$.2f(\'2g "\'+2h+\'" 2e 2b 2c 16 e 2d!\')}}})(2k);',62,153,'|||var||object|function|if|settings|itemsWidth|||childSet|methods|flexisel|true|canNavigate|nbs||listParent|innerWidth|left|width|clone|itemsVisible|css|div|false|class|responsivePoints|else|changePoint|parent|children|options|visibleItems|item|leftArrow|flexiselInner|height|rightArrow|be|adjustScroll|last|first|nav|responsiveObjects|return|this|img|animationSpeed|on|insertBefore|totalItems|scrollRight|innerHeight|arrowMargin|contentWidth|obj|find|event|complete|animate|duration|queue|linear||easing|in|px|pauseOnHover|apply|init|click|autoPlay|baseWidth|autoPlaySpeed|extend|defaults|max|right|window|setEventHandlers|break|cloneContent|resize|halfArrowHeight|top|baseHeight|add|visibility|setResponsiveEvents|insertAfter|objPosition|sortResponsiveObject|for|position|difObject|scrollLeft|appendHTML|addClass|setMaxWidthAndHeight|length|largestCustom|enableResponsiveBreakpoints|initializeItems|responsiveBreakpoints|3000|each|portrait|fadeIn|fn|trigger|200|inner|clear|640|768|tablet|li|container|wrap|ul|arrowleft|landscape|480|arrowright|slice|call|arguments|prototype|Math|ceil|Array|typeof|not|exist|plugin|does|error|Method|method|html|visible|jQuery|mouseenter|mouseleave|setInterval|continue|sort|append|hidden|push'.split('|'),0,{}))

$(document).ready(function(){
	$("#flexisel").flexisel({
		visibleItems: 5,
		animationSpeed: 1000,
		autoPlay: true,
		autoPlaySpeed: 5000,
		pauseOnHover: true,
		enableResponsiveBreakpoints: true,
		responsiveBreakpoints: {
			portrait: { 
				changePoint:480,
				visibleItems: 2
			},
			landscape: {
				changePoint:640,
				visibleItems: 3
			},
			tablet: {
				changePoint:768,
				visibleItems: 3
			}
		}
	});
});