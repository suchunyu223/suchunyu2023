<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
</div><!-- .site-content -->
	<div class="clear"></div>
	<?php if (zm_get_option('footer_link')) { ?>
		<?php get_template_part( 'template/footer-links' ); ?>
	<?php } ?>
	<?php get_template_part( 'template/footer-widget' ); ?>
	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="site-info">
		    <?php if (wp_is_mobile() and is_single()): ?>
		    <?php echo zm_get_option('footer_inf_t'); ?>
            <?php else: ?>
			<?php echo zm_get_option('footer_inf_t'); ?>
			<span class="add-info">
				<?php echo zm_get_option('footer_inf_b'); ?>
				<?php echo zm_get_option('tongji_f'); ?>
				<?php if(function_exists('performance')) performance(true) ;?> <!-- 显示页面查询次数及内存消耗 -->
			</span>
			<?php endif; ?>
		</div><!-- .site-info -->
	</footer><!-- .site-footer -->
<?php if (zm_get_option('login')) { ?>
<?php get_template_part( 'template/login' ); ?>
<?php } ?>
<?php get_template_part( 'template/scroll' ); ?>
<?php get_template_part( 'template/the-blank' ); ?>
</div><!-- .site -->
<?php wp_footer(); ?>
        
	<div class="nav">
        <ul>
        <li> <a href="https://www.suchunyu.com/"><span class="font-text"><font color="#1bff00"><i class="be be-home"></i></font> 返回网站首页</span></a></li>
        <li> <a href="tel:18364699738" rel="nofollow"><span class="font-text"><font color="#1bff00"><i class="be be-phone"></i></font> 电话咨询课程</span></a></li>
        <li> <a href="https://www.suchunyu.com/tools/htm/jiawx.html" target="_blank" rel="nofollow"><span class="font-text"><font color="#1bff00"><i class="be be-weixin"></i></font> 添加老师微信</span></a></li>
        </ul>
    </div>
    <!--百度统计代码开始-->
    <script>
      var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
           hm.src = "https://hm.baidu.com/hm.js?57af1215a90ad0e52364d5c5941430de";
        var s = document.getElementsByTagName("script")[0]; 
            s.parentNode.insertBefore(hm, s);
        })();
    </script><!--百度统计代码结束-->
             <!--禁止右键代码开始-->
    <script language="Javascript">
        document.oncontextmenu=new Function("event.returnValue=false");
        document.onselectstart=new Function("event.returnValue=false");
    </script>
    <script type="text/javascript">
        document.oncontextmenu=function(e){return false;}
    </script>
    <style>
        body {
        -moz-user-select:none;  
        }
    </style>
    <script type="text/javascript">
        document.onkeydown = function () {
            if (window.event && window.event.keyCode == 123) {
                event.keyCode = 0;
                event.returnValue = false;
                return false;
            }
        };
    </script> <!--禁止右键代码结束-->   
</body>
</html>