<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require get_template_directory() . '/inc/function.php';
require get_template_directory() . '/functions-diy.php';//删除后台无用模块，右上角"显示选项"
include('wp-clean-up/wp-clean-up.php' );//给WordPress集成WP Clean Up插件
/*彻底禁止后台显示更新的代码，降低服务器的负载 */
add_filter('pre_site_transient_update_core', function () {return null;});// 关闭核心提示
add_filter('pre_site_transient_update_themes', function () {return null;});// 关闭主题提示
add_filter('pre_site_transient_update_plugins', function () {return null;});// 关闭插件提示
remove_action('admin_init', '_maybe_update_core');// 禁止 WordPress 检查更新
remove_action('admin_init', '_maybe_update_themes');// 禁止 WordPress 更新主题
remove_action('admin_init', '_maybe_update_plugins');// 禁止 WordPress 更新插件
add_filter('automatic_updater_disabled', '__return_true');// 彻底关闭自动更新
remove_action('init', 'wp_schedule_update_checks');// 关闭更新检查定时作业
wp_clear_scheduled_hook('wp_version_check');// 移除已有的版本检查定时作业
wp_clear_scheduled_hook('wp_update_plugins');// 移除已有的插件更新定时作业
wp_clear_scheduled_hook('wp_update_themes');// 移除已有的主题更新定时作业
wp_clear_scheduled_hook('wp_maybe_auto_update');// 移除已有的自动更新定时作业
remove_action('admin_init', '_maybe_update_core');// 移除后台内核更新检查
remove_action('load-plugins.php', 'wp_update_plugins');// 移除后台插件更新检查
remove_action('load-themes.php', 'wp_update_themes');// 移除后台主题更新检查
if ( ! function_exists( 'maizi_set_no_found_rows' ) ) {
/*设置WP_Query的 'no_found_rows' 属性为true，禁用SQL_CALC_FOUND_ROWS，提高 WordPress 加载分类的分页面速度 */
    function maizi_set_no_found_rows(\WP_Query $wp_query)
    {
        $wp_query->set('no_found_rows', true);
    }
}
add_filter( 'pre_get_posts', 'maizi_set_no_found_rows', 10, 1 );
if ( ! function_exists( 'maizi_set_found_posts' ) ) {
    function maizi_set_found_posts($clauses, \WP_Query $wp_query)//使用 EXPLAIN 方式重构
    {
        if ($wp_query->is_singular()) {
            return $clauses;
        }
        global $wpdb;
        $where = isset($clauses['where']) ? $clauses['where'] : '';
        $join = isset($clauses['join']) ? $clauses['join'] : '';
        $distinct = isset($clauses['distinct']) ? $clauses['distinct'] : '';
        $wp_query->found_posts = (int)$wpdb->get_row("EXPLAIN SELECT $distinct * FROM {$wpdb->posts} $join WHERE 1=1 $where")->rows;
        $posts_per_page = (!empty($wp_query->query_vars['posts_per_page']) ? absint($wp_query->query_vars['posts_per_page']) : absint(get_option('posts_per_page')));
        $wp_query->max_num_pages = ceil($wp_query->found_posts / $posts_per_page);
        return $clauses;
    }
}
add_filter( 'posts_clauses', 'maizi_set_found_posts', 10, 2 );
/* 把插件中的站长地图放到后台顶部导航 */
function wpdocs_admin_bar_menu( $wp_admin_bar ) {
    $args = array(
        'id' => 'custom-link',
        'title' => 'SiteMAP',
        'href' => 'https://www.suchunyu.com/wp-admin/options-general.php?page=dx_seo_sitemap',//修改后台地址就可以
        'meta' => array(
            'class' => 'custom-link-class',
        )
    );
    $wp_admin_bar->add_node( $args );
}
add_action( 'admin_bar_menu', 'wpdocs_admin_bar_menu', 999 );
/* 文章段落自动换行 */
function fix_line_breaks( $content ) {
   $content_arr = explode( "\n", $content );
   $new_content = '';
   foreach( $content_arr as $line ) {
      if( ! empty( $line ) && '
' !== substr( $line, 0, 3 ) ) {
         $line = '
' . $line . '
';
      }
      $new_content .= $line . "\n";
   }
   return $new_content;
}
add_filter( 'the_content', 'fix_line_breaks', 9 );
/* 自动为没有关键词的文章添加关键词-不借助于Tag标签 */
function auto_add_keywords() {
    if(is_single()) { // 只在单篇文章页面执行
        global $post;
        $keywords = get_post_meta($post->ID, 'keywords', true); // 获取文章已有关键词
        if(!$keywords) { // 如果没有关键词则执行以下代码
            $title = $post->post_title; // 获取文章标题
            $keywords_array = array();
            $h2_titles = array();
            if(preg_match_all('/\]*\>(.+?)\<\/h2\>/', $post->post_content, $matches)) { // 匹配文章中所有的H2标题
                foreach($matches[1] as $match) {
                    $match = strip_tags($match); // 去除html标签
                    $match = preg_replace('/[\pP|\pS]/u', '', $match); // 去除标点符号
                    $match = trim($match); // 去除首尾空格
                    if(preg_match('/^(\d+)(、|\s+)/', $match)) { // 如果H2标题以数字开头，则去除数字
                        $match = preg_replace('/^(\d+)(、|\s+)/', '', $match);
                    }
                    if(preg_match('/^(一|二|三|四|第一|第二|第三|第四|第一步|第二步|第三步|第四步|方法一|方法二|方法三|方法四|步骤一|步骤二|步骤三|步骤四|原因一|原因二|原因三|原因四|第一部分|第二部分|第三部分|第四部分)/', $match)) { 
                    $match = preg_replace('/^(一|二|三|四|第一|第二|第三|第四|第一步|第二步|第三步|第四步|方法一|方法二|方法三|方法四|步骤一|步骤二|步骤三|步骤四|原因一|原因二|原因三|原因四|第一部分|第二部分|第三部分|第四部分)/', '', $match);
                    }
                    if(preg_match('/(总结|综上所述|结论|小结|结语|建议)/', $match)) { // 如果H2小标题中含有“总结、综上所述等词语”，则不再使用
                        continue;
                    }
                    $h2_titles[] = $match; // 保存H2标题到数组
                }
            }
           if($h2_titles) { // 如果存在H2标题，则将H2标题作为关键词
                foreach($h2_titles as $title) {
                    $title = mb_substr($title, 0, 12, 'utf-8'); // 截取标题中的前12个字符
                    $title = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z]/u', '', $title); // 去除非中英文字
                    if($title) {
                    $keywords_array[] = $title;
                    }
                    }
            }
			$title_parts = preg_split('/[\pP|\pS]/u', $title); // 以中文标点符号断开标题
            foreach($title_parts as $part) {
                $part = trim($part); // 去除首尾空格
                $part = mb_substr($part, 0, 12, 'utf-8'); // 截取标题中的前12个字符
                $part = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z]/u', '', $part); // 去除非中英文字符
                if($part) {
                    $keywords_array[] = $part;
                }
                if(count($keywords_array) >= 3) { // 关键词不能超过3个
                    break;
                }
            }
            if(!$keywords_array) { // 如果不存在H2标题和断开的标题，则将文章标题作为关键词
                $title = mb_substr($title, 0, 12, 'utf-8'); // 截取标题中的前12个字符
                $title = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z]/u', '', $title); // 去除非中英文字符
                if($title) {
                    $keywords_array[] = $title;
                }
            }
            $keywords_array = array_unique($keywords_array); // 去除重复的关键词
            $keywords_array = array_slice($keywords_array, 0, 3); // 最多只能有3个关键词
            $keywords_str = implode(',', $keywords_array); // 以英文逗号拼接关键词
            add_post_meta($post->ID, 'keywords', $keywords_str); // 添加关键词
            echo ''; // 插入meta标签
        } else { // 如果已经有关键词
            $keywords_array = explode(',', $keywords); // 将关键词拆分为数组
            foreach($keywords_array as &$keyword) {
                $keyword = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z]/u', '', $keyword); // 去除非中英文字符
            }
            $keywords_array = array_unique($keywords_array); // 去除重复的关键词
            $keywords_array = array_slice($keywords_array, 0, 3); // 最多只能有3个关键词
            $keywords_str = implode(',', $keywords_array); // 以英文逗号拼接关键词
            echo ''; // 插入meta标签
        }
    }
}
add_action('wp_head', 'auto_add_keywords');
/* 如果文章第一段文字低于25个汉字，在文章更新的时候，直接删除第一段，和多余代码，第一次发布不生效 */
function remove_short_first_paragraph_on_save($data, $postarr) {
    // 判断是否为新文章
    $is_new_article = !isset($postarr['ID']) || empty($postarr['ID']);
    // 如果不是新文章并且不属于分类ID为725的文章
    if (!$is_new_article && !in_array(725, $postarr['post_category'])) {
        $content = $data['post_content'];
        // 检查文章中是否存在 "p" 和 "/p" 标签，如果存在则不执行任何操作
        if (strpos($content, '') !== false) {
            return $data;
        }
        // 删除文章内容中的所有的"div"和"/div"标签
        $content = preg_replace('/<\/?div[^>]*>/', '', $content);
        // 循环删除较短的段落直到第一个段落的文字数量大于25个汉字
        do {
            $content_parts = explode("\n", $content, 2);
            $first_paragraph = strip_tags($content_parts[0]);
            $paragraph_length = mb_strlen($first_paragraph, 'utf-8');

            if ($paragraph_length < 25) {
                $content = $content_parts[1];
            }
        } while ($paragraph_length < 25);
        // 循环删除较短的段落直到最后一个段落的文字数量大于18个汉字
        do {
            $content_parts = explode("\n", $content);
            $last_paragraph = strip_tags(end($content_parts));
            $paragraph_length = mb_strlen($last_paragraph, 'utf-8');

            if ($paragraph_length < 18) {
                array_pop($content_parts);
                $content = implode("\n", $content_parts);
            }
        } while ($paragraph_length < 18);

        $data['post_content'] = $content;
    }
    return $data;
}
add_filter('wp_insert_post_data', 'remove_short_first_paragraph_on_save', 10, 2);
/* 调教WP-PostViews统计插件，减少网页被浏览的次数 */
// 更新文章浏览数时，首先更新到内存中，每10000次才写入数据库
add_filter('update_post_metadata', function ($check, $post_id, $meta_key, $meta_value) {
    if ($meta_key == 'views') {
        if ($meta_value % 10000 != 0) {
            $check = true;
            wp_cache_set($post_id, $meta_value, 'views');
        } else {
            wp_cache_delete($post_id, 'views');
        }
    }
    return $check;
}, 1, 4);
// 获取文章浏览数时，首先从内存中获取，没有则从数据库中获取
add_filter('get_post_metadata', function ($pre, $post_id, $meta_key) {
    if ($meta_key == 'views') {
        $views = wp_cache_get($post_id, 'views');
        if ($views !== false) {
            return [$views];
        }
    }
    return $pre;
}, 1, 3);
// 将首页和文章分类页面（包含分页）的文章浏览数写入内存，并优先从内存调取数据
add_action('template_redirect', function () {
    if (is_home() || is_category() || is_paged()) {
        global $wp_query;
        $post_ids = wp_list_pluck($wp_query->posts, 'ID');
        foreach ($post_ids as $post_id) {
            $views = get_post_meta($post_id, 'views', true);
            wp_cache_set($post_id, $views, 'views');
        }
    }
});
/* 直接在数据库批量关闭文章评论功能，禁止入侵者评论 */
global $wpdb;
$wpdb->query( "UPDATE wp_posts SET comment_status='close'" );
/* 解决WordPress升级到5.8以后，不显示小工具的代码 */
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );
add_filter( 'use_widgets_block_editor', '__return_false' );
/* 使用smtp发送邮件 */
add_action('phpmailer_init', 'mail_smtp');
function mail_smtp( $phpmailer ) {
	$phpmailer->FromName = '苏春宇';
	//发件人
	$phpmailer->Host = 'smtp.qq.com';
	//修改为你使用的SMTP服务器
	$phpmailer->Port = 465;
	//SMTP端口，开启了SSL加密
	$phpmailer->Username = 'mail@suchunyu.com';
	//邮箱账户   
	$phpmailer->Password = 'waucicrsjovpcbdc';
	//输入你对应的邮箱密码，这里使用了*代替
	$phpmailer->From = 'mail@suchunyu.com';
	//你的邮箱   
	$phpmailer->SMTPAuth = true;
	$phpmailer->SMTPSecure = 'ssl';
	//tls or ssl （port=25留空，465为ssl）
	$phpmailer->IsSMTP();
}
/* 禁用标签功能 */
function ruike_unregister_post_tag() {
	unregister_taxonomy_for_object_type('post_tag', 'post');
}
add_action( 'init', 'ruike_unregister_post_tag' );
/* WordPress 媒体库只显示用户自己上传的文件 */
//在文章编辑页面的[添加媒体]只显示用户自己上传的文件
function my_upload_media( $wp_query_obj ) {
	global $current_user, $pagenow;
	if( !is_a( $current_user, 'WP_User') )
			return;
	if( 'admin-ajax.php' != $pagenow || $_REQUEST['action'] != 'query-attachments' )
			return;
	if( !current_user_can( 'manage_options' ) && !current_user_can('manage_media_library') )
			$wp_query_obj->set('author', $current_user->ID );
	return;
}
add_action('pre_get_posts','my_upload_media');
//在[媒体库]只显示用户上传的文件
function my_media_library( $wp_query ) {
	if ( strpos( $_SERVER[ 'REQUEST_URI' ], '/wp-admin/upload.php' ) !== false ) {
		if ( !current_user_can( 'manage_options' ) && !current_user_can( 'manage_media_library' ) ) {
			global $current_user;
			$wp_query->set( 'author', $current_user->id );
		}
	}
}
add_filter('parse_query', 'my_media_library' );
/* 注册用户验证屏蔽注册机 */
add_action( 'register_form', 'add_security_question' );
function add_security_question() {
	?>
	    <p>
	    <label><?php _e('请输入本站域名：www.suchunyu.com') ?><br />
	        <input type="text" name="user_proof" id="user_proof" class="input" size="25" tabindex="20" /></label>
	    </p>
	<?php
}
add_action( 'register_post', 'add_security_question_validate', 10, 3 );
function add_security_question_validate( $sanitized_user_login, $user_email, $errors) {
	// 如果没有回答
	if (!isset($_POST[ 'user_proof' ]) || empty($_POST[ 'user_proof' ])) {
		return $errors->add( 'proofempty', '<strong>错误</strong>: 您还没有回答问题。'  );
		// 如果答案不正确
	} elseif ( strtolower( $_POST[ 'user_proof' ] ) != 'https://www.suchunyu.com' ) {
		return $errors->add( 'prooffail', '<strong>错误</strong>: 您的回答不正确。'  );
	}
}
/* 添加友情链接nofollow标签选项 */
add_action('load-link.php', 'sola_blogroll_nofollow');
add_action('load-link-add.php', 'sola_blogroll_nofollow');
function sola_blogroll_nofollow() {
	//通过action add_meta_boxes创建我们需要的Meta Box
	add_action('add_meta_boxes', 'sola_blogroll_add_meta_box', 1, 1);
	//通过filter pre_link_rel将数据保存
	add_filter('pre_link_rel', 'sola_blogroll_save_meta_box', 10, 1);
}
//创建Nofollow Meta Box
function sola_blogroll_add_meta_box() {
	//翻译成中文就是，创建一个名叫Blogroll Nofollow的Meta Box，放在link页面的右侧边栏，Meta Box的结构
	//由函数sola_blogroll_inner_meta_box产生
	add_meta_box('sola_blogroll_nofollow_div', __('Nofollow标签'), 'sola_blogroll_inner_meta_box', 'link', 'side');
}
//输出Meta Box的HTML结构
function sola_blogroll_inner_meta_box($post) {
	$bookmark = get_bookmark($post->ID, 'ARRAY_A');
	if (strpos($bookmark['link_rel'], 'nofollow') !== FALSE)
	        $checked = ' checked="checked"'; else
	        $checked = '';
	?>
	    <label for="sola_blogroll_nofollow_checkbox"><?php echo __('是否添加Nofollow标签?');
	?></label>
	    <input value="1" id="sola_blogroll_nofollow_checkbox" name="sola_blogroll_nofollow_checkbox" type="checkbox"<?php echo $checked;
	?> />
	    <?php
}
//保存用户的选择
function sola_blogroll_save_meta_box($link_rel) {
	$rel = trim(str_replace('nofollow', '', $link_rel));
	if ($_POST['sola_blogroll_nofollow_checkbox'])
	        $rel .= ' nofollow';
	return trim($rel);
}
/* 文章外链自动添加nofollow属性和新窗口打开 */
add_filter( 'the_content', 'cn_nf_url_parse');
function cn_nf_url_parse( $content ) {
	$regexp = "<a\s[^>]*href=(\"??)([^\" >]*?)\\1[^>]*>";
	if(preg_match_all("/$regexp/siU", $content, $matches, PREG_SET_ORDER)) {
		if( !empty($matches) ) {
			$srcUrl = get_option('siteurl');
			for ($i=0; $i < count($matches); $i++) {
				$tag = $matches[$i][0];
				$tag2 = $matches[$i][0];
				$url = $matches[$i][0];
				$noFollow = '';
				$pattern = '/target\s*=\s*"\s*_blank\s*"/';
				preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
				if( count($match) < 1 )
									$noFollow .= ' target="_blank" ';
				$pattern = '/rel\s*=\s*"\s*[n|d]ofollow\s*"/';
				preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
				if( count($match) < 1 )
									$noFollow .= ' rel="nofollow" ';
				$pos = strpos($url,$srcUrl);
				if ($pos === false) {
					$tag = rtrim ($tag,'>');
					$tag .= $noFollow.'>';
					$content = str_replace($tag2,$tag,$content);
				}
			}
		}
	}
	$content = str_replace(']]>', ']]>', $content);
	return $content;
}
/* 去文章图片链接*/
function wpc_imagelink_setup() {
	$image_set = get_option( 'image_default_link_type' );
	if ($image_set !== 'none') {
		update_option('image_default_link_type', 'none');
	}
}
add_action('admin_init', 'wpc_imagelink_setup', 10);
/* 上传图片自动按照上传日期重命名 */
add_filter('wp_handle_upload_prefilter', 'custom_upload_filter' );
function custom_upload_filter( $file ) {
	$info = pathinfo($file['name']);
	$ext = $info['extension'];
	$filedate = date('YmdHis').rand(10,99);
	//为了避免时间重复，再加一段2位的随机数
	$file['name'] = $filedate.'.'.$ext;
	return $file;
}
/* 禁止一个账号多人使用，一个登录，另一个被顶掉 */
function pcl_user_has_concurrent_sessions() {
	return ( is_user_logged_in() && count( wp_get_all_sessions() ) > 1 );
}
function pcl_get_current_session() {
	$sessions = WP_Session_Tokens::get_instance( get_current_user_id() );
	return $sessions->get( wp_get_session_token() );
}
function pcl_disallow_account_sharing() {
	if ( ! pcl_user_has_concurrent_sessions() ) {
		return;
	}
	$newest  = max( wp_list_pluck( wp_get_all_sessions(), 'login' ) );
	$session = pcl_get_current_session();
	if ( $session['login'] === $newest ) {
		wp_destroy_other_sessions();
	} else {
		wp_destroy_current_session();
	}
}
add_action( 'init', 'pcl_disallow_account_sharing' );
//记录登录用户IP地址
//透过代理或者cdn获取访客真实IP
function get_client_ip() {
	if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
	        $ip = getenv("HTTP_CLIENT_IP"); else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), 
	"unknown"))
	        $ip = getenv("HTTP_X_FORWARDED_FOR"); else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
	        $ip = getenv("REMOTE_ADDR"); else if (isset ($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] 
	&& strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
	        $ip = $_SERVER['REMOTE_ADDR']; else
	        $ip = "unknown";
	return ($ip);
}
// 创建一个新字段存储用户注册时的IP地址
add_action('user_register', 'log_ip');
function log_ip($user_id) {
	$ip = get_client_ip();
	update_user_meta($user_id, 'signup_ip', $ip);
}
// 创建新字段存储用户登录时间和登录IP
add_action( 'wp_login', 'insert_last_login' );
function insert_last_login( $login ) {
	global $user_id;
	$user = get_userdatabylogin( $login );
	update_user_meta( $user->ID, 'last_login', current_time( 'mysql' ) );
	$last_login_ip = get_client_ip();
	update_user_meta( $user->ID, 'last_login_ip', $last_login_ip);
}
// 添加额外的栏目
add_filter('manage_users_columns', 'add_user_additional_column');
function add_user_additional_column($columns) {
	$columns['user_nickname'] = '昵称';
	$columns['reg_time'] = '注册时间';
	$columns['last_login'] = '上次登录';
	// 打算将注册IP和注册时间、登录IP和登录时间合并显示，所以我注销下面两行
	/*$columns['signup_ip'] = '注册IP';
    $columns['last_login_ip'] = '登录IP';*/
	unset($columns['name']);
	//移除“姓名”这一栏，如果你需要保留，删除这行即可
	return $columns;
}
//显示栏目的内容
add_action('manage_users_custom_column',  'show_user_additional_column_content', 10, 3);
//输出注册时间和注册IP以及最近登录时间
function show_user_additional_column_content($value, $column_name, $user_id) {
	$user = get_userdata( $user_id );
	// 输出“昵称”
	if ( 'user_nickname' == $column_name )
	        return $user->nickname;
	// 输出注册时间和注册IP
	if('reg_time' == $column_name ) {
		return get_date_from_gmt($user->user_registered) .'
'.get_user_meta( $user->ID, 'signup_ip', true);
	}
	// 输出最近登录时间和登录IP
	if ( 'last_login' == $column_name && $user->last_login ) {
		return get_user_meta( $user->ID, 'last_login', true ).'
'.get_user_meta( $user->ID, 'last_login_ip', true );
	}
	return $value;
}
// 默认按照注册时间排序
add_filter( "manage_users_sortable_columns", 'cmhello_users_sortable_columns' );
function cmhello_users_sortable_columns($sortable_columns) {
	$sortable_columns['reg_time'] = 'reg_time';
	return $sortable_columns;
}
add_action( 'pre_user_query', 'cmhello_users_search_order' );
function cmhello_users_search_order($obj) {
	if(!isset($_REQUEST['orderby']) || $_REQUEST['orderby']=='reg_time' ) {
		if( !in_array($_REQUEST['order'],array('asc','desc')) ) {
			$_REQUEST['order'] = 'desc';
		}
		$obj->query_orderby = "ORDER BY user_registered ".$_REQUEST['order']."";
	}
}
/* 文章/页面编辑页面添加选项-搜索引擎专属 */
function ludouseo_add_custom_box() {
	add_meta_box('ludou_se_only', '搜索引擎专属', 'ludou_se_only', 'post', 'side', 'low');
	add_meta_box('ludou_se_only', '搜索引擎专属', 'ludou_se_only', 'page', 'side', 'low');
}
add_action('add_meta_boxes', 'ludouseo_add_custom_box');
function ludou_se_only() {
	global $post;
	//添加验证字段
	wp_nonce_field('ludou_se_only', 'ludou_se_only_nonce');
	$meta_value = get_post_meta($post->ID, 'ludou_se_only', true);
	if($meta_value)
	    echo '<input name="ludou-se-only" type="checkbox" checked="checked" value="1" /> 只允许搜索引擎查看'; else
	    echo '<input name="ludou-se-only" type="checkbox" value="1" /> 只允许搜索引擎查看';
}
// 保存选项设置
function ludouseo_save_postdata($post_id) {
	// 验证
	if ( !isset( $_POST['ludou_se_only_nonce']))
	    return $post_id;
	$nonce = $_POST['ludou_se_only_nonce'];
	// 验证字段是否合法
	if (!wp_verify_nonce( $nonce, 'ludou_se_only'))
	    return $post_id;
	// 判断是否自动保存
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
	      return $post_id;
	// 验证用户权限
	if ('page' == $_POST['post_type']) {
		if ( !current_user_can('edit_page', $post_id))
		      return $post_id;
	} else {
		if (!current_user_can('edit_post', $post_id))
		      return $post_id;
	}
	// 更新设置
	if(!empty($_POST['ludou-se-only']))
	    update_post_meta($post_id, 'ludou_se_only', '1'); else
	    delete_post_meta($post_id, 'ludou_se_only');
}
add_action('save_post', 'ludouseo_save_postdata');
function do_ludou_se_only() {
	// 本功能只对文章和页面有效
	if(is_singular()) {
		global $post;
		$is_robots = 0;
		$ludou_se_only = get_post_meta($post->ID, 'ludou_se_only', true);
		if(!empty($ludou_se_only)) {
			// 下面是搜索引擎Agent判断关键字数组
			// 有点简单，自己优化一下吧
			$bots = array(
			            'Baiduspider',
			            'Googlebot',
			            'sogou spider',
			            'Sogou web spider',
			            'YodaoBot',
			            'Bingbot',
			            '360Spider',
			            'Slurp',
			            'MSNBot',
			            'yahoo-blogs',
			            'psbot',
			            'Yandex',
			            'blogsearch',
			            'EasouSpider',
			            'Mediapartners-Google'
			            );
			$useragent = $_SERVER['HTTP_USER_AGENT'];
			if(!empty($useragent)) {
				foreach ($bots as $lookfor) {
					if (stristr($useragent, $lookfor) !== false) {
						$is_robots = 1;
						break;
					}
				}
			}
			// 如果不是搜索引擎，显示错误信息
			// 已登录的用户不受影响
			if(!$is_robots && !is_user_logged_in()) {
				wp_die('<br>学习<strong>百度搜索排名</strong>、网站SEO优化、SEM、网络推广等，请点击第一个按钮或点击：<a href="https://www.suchunyu.com/index.php/videos.html" target="_blank"  style="color:red;">【百度SEO试学课程】</a><br>
<br>
学习<strong>淘宝电商运营</strong>、拼多多、阿里巴巴运营、网店运营，请点击第二个按钮或点击：<a href="https://www.suchunyu.com/yunying.html" target="_blank"  style="color:red;">【淘宝电商试学课程】</a><br>
<br>
学习<strong>快手/抖音运营</strong>，涨粉丝、上热门、带货等直播电商课程，请点击第三个按钮或者：<a href="https://www.suchunyu.com/kuaishou.html" 
 target="_blank" style="color:red;">【快手运营试学课程】</a>   ');
			}
		}
	}
}
add_action('wp', 'do_ludou_se_only');
/* WordPress 移除链接中的 rel="noopener" 属性 */
add_filter('tiny_mce_before_init','tinymce_allow_unsafe_link_target');
function tinymce_allow_unsafe_link_target( $mceInit ) {
	$mceInit['allow_unsafe_link_target']=true;
	return $mceInit;
}
/* 修改启用密码保护时的提示字样 */
add_filter( 'the_password_form', 'zhang_the_password_form' );
function zhang_the_password_form() {
	global $post;
	$label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
	$output = '<form action="' . esc_url( site_url( 'wp-login.php?action=postpass', 'login_post' ) ) . ' " class="post-password-form" method="post">' . __( "<p>本节是加密课程，您需要输入您的【激活码】，进行学习：</p>" ) . '<p><label for="post_password">激活码：</label><input name="post_password" id="' . $label . '" type="password" size="20" maxlength="20" style="height:24px;" /><input type="submit" name="Submit" value="' . esc_attr__( "提交" ) . '" style="width:50px;height:28px;" /></p></form>';
	return $output;
}
/* 替换文章图片链接为 https */
function https_image_replacer($content) {
	if( is_ssl() ) {
		$host_name = $_SERVER['HTTP_HOST'];
		$http_host_name='http://'.$host_name.'/wp-content/uploads';
		$https_host_name='https://'.$host_name.'/wp-content/uploads';
		$content = str_replace($http_host_name, $https_host_name, $content);
	}
	return $content;
}
add_filter('the_content', 'https_image_replacer');
/* 显示页面查询次数、加载时间和内存占用 */
function performance( $visible = false ) {
	$stat = sprintf( '本页面加载共：%d 次查询 | 用时 %.1f 秒 | 占用 %.1fMB 内存',
	get_num_queries(),
	timer_stop( 0, 1 ),
	memory_get_peak_usage() / 1024 / 1024
	);
	echo $visible ? $stat : "<!-- {$stat} -->" ;
}
/* WordPress SSL 绝对链接替换 */
add_filter('get_header', 'fanly_ssl');
function fanly_ssl() {
	if( is_ssl() ) {
		function fanly_ssl_main ($content) {
			$siteurl = get_option('siteurl');
			$upload_dir = wp_upload_dir();
			$content = str_replace( 'http:'.strstr($siteurl, '//'), 'https:'.strstr($siteurl, '//'), $content);
			$content = str_replace( 'http:'.strstr($upload_dir['baseurl'], '//'), 'https:'.strstr($upload_dir['baseurl'], '//'), $content);
			return $content;
		}
		ob_start("fanly_ssl_main");
	}
}
/* 文章内容去除alt空标签 */
function wpdaxue_replace_text($text) {
	$replace = array(
			// '原始文字' => '替换为这些'
	' alt=""' => '',
			);
	$text = str_replace(array_keys($replace), $replace, $text);
	return $text;
}
add_filter('the_content', 'wpdaxue_replace_text');
/* WordPress “添加媒体”文件时只显示上传到当前文章的附件 */
add_action( 'wp_footer', 'fanly_mediapanel_lock_uploaded' );//让前台编辑器也生效
add_action( 'admin_footer-post-new.php', 'fanly_mediapanel_lock_uploaded' );
add_action( 'admin_footer-post.php', 'fanly_mediapanel_lock_uploaded' );
function fanly_mediapanel_lock_uploaded() {
	echo '<script type="text/javascript">var $i=0;jQuery(document).on("DOMNodeInserted", function(){if(jQuery("#media-attachment-filters").length>0&&$i==0){jQuery(\'select.attachment-filters [value="uploaded"]\').attr(\'selected\',true).parent().trigger(\'change\');$i++;}});</script>';
}

/* 屏蔽关键词恶意搜索 */
add_action('admin_init', 'php_search_ban_key');
function php_search_ban_key() {
    add_settings_field('php_search_key', '搜索关键词屏蔽', 'php_search_key_callback_function', 'reading');
    register_setting('reading','php_search_key');
}
 
function php_search_key_callback_function() {
    echo '<textarea name="php_search_key" rows="10" cols="50" id="php_search_key" class="large-text code">' .
     
    get_option('php_search_key') . '</textarea>';
}
add_action('template_redirect', 'php_search_ban');
function php_search_ban(){
if (is_search()) {
    global $wp_query;
    $php_search_key = get_option('php_search_key');
        if($php_search_key){
        $php_search_key = str_replace("\r\n", "|", $php_search_key);
        $BanKey = explode('|', $php_search_key);
        $S_Key = $wp_query->query_vars;
            foreach($BanKey as $Key){
                if( stristr($S_Key['s'],$Key) != false ){
                echo '</Br><h2><span style="color: #ff0000;"><p style="text-align: center;">本站提示：文明使用网络，此关键词在本站禁止被搜索！</Br></Br><a href="https://www.suchunyu.com/">点此返回首页</a></p></span></h2>';die();
                }
            }
        }
    }
}
/* 自动设置文章第一张图为特色图片 */
function wpforce_featured() {
    global $post;
    $already_has_thumb = has_post_thumbnail($post->ID);
    if (!$already_has_thumb)  {
        $attached_image = get_children( "post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=1" );
        if ($attached_image) {
                foreach ($attached_image as $attachment_id => $attachment) {
                set_post_thumbnail($post->ID, $attachment_id);
            }
        }
    }
}  //end function
add_action('the_post', 'wpforce_featured');
add_action('save_post', 'wpforce_featured');
add_action('draft_to_publish', 'wpforce_featured');
add_action('new_to_publish', 'wpforce_featured');
add_action('pending_to_publish', 'wpforce_featured');
add_action('future_to_publish', 'wpforce_featured');
/* 禁用 feed防止文章被采集 */
function disable_our_feeds() {
wp_die( __('Error: No RSS Feed Available, Please visit our homepage.'));
}
add_action('do_feed', 'disable_our_feeds', 1);
add_action('do_feed_rdf', 'disable_our_feeds', 1);
add_action('do_feed_rss', 'disable_our_feeds', 1);
add_action('do_feed_rss2', 'disable_our_feeds', 1);
add_action('do_feed_atom', 'disable_our_feeds', 1);
//禁止网页中生成feed地址
remove_action( 'wp_head', 'feed_links_extra', 3 );
remove_action( 'wp_head', 'feed_links', 2 );
/* 禁止网站被频繁请求，防止文章被采集，同时防范CC攻击 */
ini_set("display_errors", "Off");
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
extension_loaded('memcached') or die('memcached扩展未安装！');
$fileht = $_SERVER['DOCUMENT_ROOT'] . '/waf/ban.log'; //被拉黑IP记录文件保存路径，如果因测试被封禁，删除该文件中测试IP，然后到宝塔面板首页重启memcached服务即可恢复
if (!file_exists($fileht)) {
    @mkdir($_SERVER['DOCUMENT_ROOT'] . '/waf/', 0777, true);
    @file_put_contents($fileht, '');
}
$allowtime_1 = 6; //防刷新时间（秒）
$allownum_1 = 5; //防刷新次数（比如6秒5次，超过就拉黑）
$allowtime_2 = 3600; //防刷新时间（秒）
$allownum_2 = 50; //防刷新次数（比如3600秒50次，超过就拉黑）
$allowtime_3 = 18000; //防刷新时间（秒）
$allownum_3 = 80; //防刷新次数（比如18000秒80次，超过就拉黑）
$bantime = 31536000; //封禁时间一年，超时自动解封（秒）
$ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
$uri = $_SERVER['PHP_SELF'];
$cache = new Memcached();
$cache->addServer('127.0.0.1', '11211') or die('memcached连接失败！');
$inban = $cache->get('waf-ban-' . $ip);
//设置白名单，排除自己常用IP和服务器IP
$allowIp = array('39.90.239.0','123.131.103.146','223.78.245.175','8.210.54.110');//填写你的常用IP和服务器IP地址
if (in_array($ip, $allowIp)){  //判断$ip是否存在于$allowIp的数组中，如果在，则…
    return false;//终止向下执行
} else {
     if ($inban) {
        header("HTTP/1.1 403 Forbidden");
        exit('<h1>403 Forbidden 非法访问</h1>
<p>你的请求似乎不符合常理，已被服务器防火墙拦截，如有疑问请联系本站管理员；</br>如果你是在采集本站文章过程中超频被封IP，请等待500年后自动解封；</br>你的IP：' . $ip . '</p>');
    }
    $wafarr = $cache->get('waf-' . $ip);
    if (!$wafarr) {
        $wafarr = [
            'path' => $uri,
            'time' => time(),
            'sum' => 1,
        ];
        $cache->set('waf-' . $ip, $wafarr, $allowtime_3);
    } else {
        $elapsed_time = time() - $wafarr['time'];
        if (($elapsed_time <= $allowtime_1 && $wafarr['sum'] >= $allownum_1) ||
            ($elapsed_time <= $allowtime_2 && $wafarr['sum'] >= $allownum_2) ||
            ($elapsed_time <= $allowtime_3 && $wafarr['sum'] >= $allownum_3)) {
            $cache->set('waf-ban-' . $ip, 1, time() + $bantime);
            file_put_contents($fileht, $ip . '--' . date('Y-m-d H:i:s', time()+8*60*60) . "\n", FILE_APPEND);
            header("HTTP/1.1 403 Forbidden");
            exit('<h1>403 Forbidden 非法访问</h1>
<p>你的请求似乎不符合常理，已被服务器防火墙拦截，如有疑问请联系本站管理员；</br>如果你是在采集本站文章过程中超频被封IP，请等待500年后自动解封；</br>你的IP：' . $ip . '</p>');
        } else {
            $wafarr['sum']++;
            $cache->set('waf-' . $ip, $wafarr, $allowtime_3);
        }
    }
}
/* 屏蔽假的搜索引擎蜘蛛，防止网站被CC攻击 */
function cc_attack_protection() {
    if ( ! is_user_logged_in() ) {
        if ( isset( $_SERVER['HTTP_USER_AGENT'] ) && strlen( $_SERVER['HTTP_USER_AGENT'] ) > 25 ) {
            $bots = array( 'Baiduspider', 'Baiduspider-image', '360Spider', 'Sogou Spider', 'Sogou web spider', 'Sogou inst spider', 'Bytespider', 'bingbot', 'sosospider', 'msnbot', 'YoudaoBot', 'YodaoBot', 'YisouSpider' );//这段代码会检测HTTP_USER_AGENT是否存在并且长度大于25，接着会排除搜索引擎爬虫，只拒绝真正的攻击者的请求。
            foreach ( $bots as $bot ) {
                if ( stripos( $_SERVER['HTTP_USER_AGENT'], $bot ) !== false ) {
                    status_header( 403 );
                    exit;
                }
            }
        }
    }
}
/* 禁用网站的/xmlrpc.php功能，防止被暴力破解 */
add_filter('xmlrpc_enabled', '__return_false');
/* 防止恶意 HTTP_USER_AGENT 采集 */
$ua = $_SERVER['HTTP_USER_AGENT'];//获取UA信息
$now_ua = array('FeedDemon ','BOT\/0.1 (BOT for JCE)','CrawlDaddy ','Java','Feedly','UniversalFeedParser','ApacheBench','Swiftbot','ZmEu','Indy Library','oBot','jaunty','YandexBot','AhrefsBot','MJ12bot','WinHttp','EasouSpider','HttpClient','Microsoft URL Control','YYSpider','jaunty','Python-urllib','lightDeckReports Bot');//将恶意USER_AGENT存入数组
if(!$ua) {
header("Content-type: text/html; charset=utf-8");
die('请勿采集本站，原创不易，请高抬贵手！');//禁止空USER_AGENT，dedecms等主流采集程序都是空USER_AGENT，部分sql注入工具也是空USER_AGENT
}else{
foreach($now_ua as $value ){
if(preg_match("/{$value}/",$ua)>0) {
header("Content-type: text/html; charset=utf-8");
die('请勿采集本站，原创不易，请高抬贵手！');
}
}
}
