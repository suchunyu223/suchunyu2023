<?php 
function add_internal_links($content) {
    global $post;

    // 排除分类ID为725的文章
    if (in_category(725, $post->ID)) {
        return $content;
    }

    $keywords = array(
        '平面设计培训',
        'SEO培训',
        '建网站',
        '短视频',
        '涨粉丝',
        '网站建设',
        '网络推广',
        '微信营销',
        '快手培训'
    );

    // 获取符合条件的文章
    $args = array(
        'category__not_in' => array(725),
        'date_query' => array(
            array(
                'column' => 'post_date',
                'before' => '-15 days'
            ),
        ),
        'orderby' => 'date',
        'order' => 'DESC',
        'posts_per_page' => -1,
    );

    $query = new WP_Query($args);
    $posts = $query->get_posts();

    // 如果没有符合条件的文章，直接返回内容
    if (empty($posts)) {
        return $content;
    }

    // 按关键词查找文章并替换内容
    $content_parts = explode("\n", $content);
    $links_added = 0;

    for ($i = 2; $i < count($content_parts) && $links_added < 3; $i++) {
        $paragraph = $content_parts[$i];

        if (strpos($paragraph, '
') === false && strpos($paragraph, '
') === false) {
            $replaced = false;

            shuffle($keywords);

            foreach ($keywords as $keyword) {
                if (strpos($paragraph, $keyword) !== false) {
                    foreach ($posts as $post) {
                        if (strpos($post->post_title, $keyword) !== false) {
                            $url = get_permalink($post->ID);
                            $paragraph = preg_replace('/' . preg_quote($keyword, '/') . '/', '' . $keyword . '', $paragraph, 1);
                            $replaced = true;
                            $links_added++;
                            break;
                        }
                    }

                    if ($replaced) {
                        break;
                    }
                }
            }

            $content_parts[$i] = $paragraph;
        }
    }

    $content = implode("\n", $content_parts);

    return $content;
}
add_filter('the_content', 'add_internal_links');