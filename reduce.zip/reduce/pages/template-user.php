<?php
/*
Template Name: 用户中心
*/
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<?php if(is_user_logged_in()){?>
<?php get_header(); ?>
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/user-center.css" />


<div id="personal">	
	<div id="container">
		<div id="usertab">
			<div class="resp-tabs-container hor_1">
				<div>
					<h4><?php _e( '&nbsp;&nbsp;一、我的信息', 'begin' ); ?></h4>
					<?php get_template_part( 'inc/users/my-inf' ); ?>
					<div class="clear"></div>
				</div>
				<div>
					<h4><?php _e( '&nbsp;&nbsp;二、我的文章', 'begin' ); ?><span class="m-number">（ <?php $userinfo=get_userdata(get_current_user_id()); $authorID= $userinfo->ID; echo num_of_author_posts($authorID); ?> 篇 ）<span></h4>
					<?php get_template_part( 'inc/users/my-post' ); ?>
				</div>
				<div>
					<h4><?php _e( '&nbsp;&nbsp;三、我要投稿', 'begin' ); ?></h4>
					<?php get_template_part( 'inc/users/my-tou' ); ?>
					<div class="clear"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="clear"></div>
</div>

<?php get_footer(); ?>
<?php }else{
 wp_redirect( home_url() );
 exit;
}?>