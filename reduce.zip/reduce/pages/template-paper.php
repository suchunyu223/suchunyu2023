<?php
/*
Template Name: 空白模板
*/
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<?php get_header(); ?>


    <div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
	
            <?php while ( have_posts() ) : the_post(); ?>
	<div class="entry-content">

             <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<div class="single-content">
				<?php the_content(); ?>
			</div>
             </article>	
	</div><!-- .entry-content -->

		
                  
	<?php endwhile; ?>
	</main><!-- .site-main -->
    </div><!-- .content-area -->


<?php get_sidebar(); ?>

<?php get_footer(); ?>