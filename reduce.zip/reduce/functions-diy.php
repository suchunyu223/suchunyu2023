<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
//删除顶部工具栏
function my_edit_toolbar($wp_toolbar) {
    $wp_toolbar->remove_node('wp-logo'); // 去掉 WordPress LOGO
    $wp_toolbar->remove_node('updates'); // 去掉更新提醒
    $wp_toolbar->remove_node('comments'); // 去掉评论提醒
    $wp_toolbar->remove_node('new-content'); // 去掉新建文件
    $wp_toolbar->remove_node('top-secondary'); // 用户信息
    
}
add_action('admin_bar_menu', 'my_edit_toolbar', 999);
//删除左侧子菜单首页和更新
function remove_submenu() {
    // 删除仪表盘下的首页
    remove_submenu_page('index.php', 'index.php');
    // 删除仪表盘下的更新
    remove_submenu_page('index.php', 'update-core.php');
}
if (is_admin()) {
    //删除子菜单
    add_action('admin_init', 'remove_submenu');
}
//删除仪表盘无用模块
function example_remove_dashboard_widgets() {
    global $wp_meta_boxes;
    // 以下这一行代码将删除 "快速发布" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    // 以下这一行代码将删除 "引入链接" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
    // 以下这一行代码将删除 "插件" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    // 以下这一行代码将删除 "近期评论" 模块
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    // 以下这一行代码将删除 "近期草稿" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_recent_drafts']);
    // 以下这一行代码将删除 "WordPress 开发日志" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    // 以下这一行代码将删除 "其它 WordPress 新闻" 模块
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
}
add_action('wp_dashboard_setup', 'example_remove_dashboard_widgets');
//删除显示选项和帮助选项卡
function remove_screen_options() {
    return false;
}
add_filter('screen_options_show_screen', 'remove_screen_options');
add_filter('contextual_help', 'syz_remove_help', 999, 3);
function syz_remove_help($old_help, $screen_id, $screen) {
    $screen->remove_help_tabs();
    return $old_help;
}
//页脚版本信息
function change_footer_admin() {
    return '';
}
add_filter('admin_footer_text', 'change_footer_admin', 9999);
function change_footer_version() {
    return '';
}
add_filter('update_footer', 'change_footer_version', 9999);