<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found page">
				<header class="entry-header">
					<h1 class="page-title"><?php echo stripslashes( zm_get_option('404_t') ); ?></h1>
				</header><!-- .page-header -->
				<div class="single-content">
					<p style="text-align: center;"><?php echo stripslashes( zm_get_option('404_c') ); ?></p>
				<br />
                      <h2>  当然，您也可以尝试搜索来获取相关内容哦！</h2>
				<br />
					<?php get_search_form(); ?>
					<br />
					<div class='subscribe'><fieldset><legend>重要提示</legend> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;学习 <strong>百度搜索排名</strong>、<strong>淘宝电商运营</strong>、<strong>快手直播带货</strong> 等【<strong>互联网营销培训</strong>】课程，敬请联系<strong>苏春宇老师</strong>，含百度<strong>SEO</strong>/SEM、拼多多运营、平面设计（<strong>PS</strong>）、网站建设，网络推广等，<strong>苏老师手机号/微信：<em>183 6469 9738</em></strong></fieldset>
					</div>
				</div><!-- .page-content -->
				<?php if (zm_get_option('single_weixin')) { ?>
					<?php get_template_part( 'template/weixin' ); ?>
				<?php } ?>
				<?php get_template_part('ad/ads', 'single-b'); ?>
			</section><!-- .error-404 -->
				
				<?php if (zm_get_option('related_img')) { ?>
					<?php get_template_part( 'template/related-img' ); ?>
				<?php } ?>
				<?php get_template_part( 'template/single-widget' ); ?>
                <nav class="nav-single wow fadeInUp" data-wow-delay="0.3s">
					<?php
						if (get_previous_post( TRUE )) { previous_post_link( '%link','<span class="meta-nav"><span class="post-nav"><i class="be be-arrowleft"></i> ' . sprintf(__( '上一篇', 'begin' )) . '</span><br/>%title</span>', TRUE ); } else { echo "<span class='meta-nav'><span class='post-nav'>" . sprintf(__( '没有了', 'begin' )) . "<br/></span>" . sprintf(__( '已是最后文章', 'begin' )) . "</span>"; }
						if (get_next_post( TRUE )) { next_post_link( '%link', '<span class="meta-nav"><span class="post-nav">' . sprintf(__( '下一篇', 'begin' )) . ' <i class="be be-arrowright"></i></span><br/>%title</span>', TRUE ); } else { echo "<span class='meta-nav'><span class='post-nav'>" . sprintf(__( '没有了', 'begin' )) . "<br/></span>" . sprintf(__( '已是最新文章', 'begin' )) . "</span>"; }
					?>
					<div class="clear"></div>
				</nav>
		</main><!-- .site-main -->
	</div><!-- .content-area -->
	
<?php get_sidebar(); ?>
<?php get_footer(); ?>